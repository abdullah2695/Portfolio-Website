import { useState, useEffect } from 'react';
import Layout from './components/layout/Layout';
import './App.css';

// Import data
import { personalInfo } from './data/personalInfo';
import { experience } from './data/experience';
import { siteConfig } from './data/siteConfig';

function App() {
  // State for the contact form
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  
  // State for form submission
  const [formStatus, setFormStatus] = useState({
    submitted: false,
    success: false,
    message: ''
  });
  
  // State for showing the message field in the contact form
  const [showMessageField, setShowMessageField] = useState(personalInfo.enableContactForm);
  
  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const response = await fetch(siteConfig.formspreeEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });
      
      if (response.ok) {
        setFormStatus({
          submitted: true,
          success: true,
          message: 'Thank you! Your message has been sent successfully.'
        });
        
        // Reset form
        setFormData({
          name: '',
          email: '',
          subject: '',
          message: ''
        });
      } else {
        setFormStatus({
          submitted: true,
          success: false,
          message: 'Oops! Something went wrong. Please try again later.'
        });
      }
    } catch (error) {
      setFormStatus({
        submitted: true,
        success: false,
        message: 'Oops! Something went wrong. Please try again later.'
      });
    }
  };
  
  // Reset form status after 5 seconds
  useEffect(() => {
    if (formStatus.submitted) {
      const timer = setTimeout(() => {
        setFormStatus({
          submitted: false,
          success: false,
          message: ''
        });
      }, 5000);
      
      return () => clearTimeout(timer);
    }
  }, [formStatus.submitted]);

  return (
    <Layout>
      {/* Hero Section */}
      <section id="home" className="section bg-gradient-to-b from-background to-muted">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 text-primary">
                {personalInfo.name}
              </h1>
              <p className="text-xl md:text-2xl mb-6 text-muted-foreground">
                {personalInfo.headline}
              </p>
              <div className="flex space-x-4">
                <a href="#contact" className="btn btn-primary">
                  Contact Me
                </a>
                <a href="#about" className="btn btn-secondary">
                  Learn More
                </a>
              </div>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <div className="w-64 h-64 rounded-full bg-muted flex items-center justify-center border-4 border-primary">
                {/* Profile image will go here */}
                <span className="text-6xl font-bold text-primary">
                  {personalInfo.name.charAt(0)}
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="section">
        <div className="container">
          <h2 className="section-title">About Me</h2>
          <div className="card">
            <p className="text-lg leading-relaxed">
              {personalInfo.bio}
            </p>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="section bg-muted">
        <div className="container">
          <h2 className="section-title">Work Experience</h2>
          <div className="space-y-8">
            {experience.map((job) => (
              <div key={job.id} className="experience-item">
                <h3 className="experience-title">{job.title}</h3>
                <p className="experience-company">{job.company}</p>
                <p className="experience-period">{job.period} | {job.location}</p>
                <ul className="mt-4 space-y-2">
                  {job.responsibilities.map((responsibility, index) => (
                    <li key={index} className="flex items-start">
                      <span className="mr-2 text-primary">•</span>
                      <span>{responsibility}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="section">
        <div className="container">
          <h2 className="section-title">Contact Me</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            {/* Contact Information */}
            <div className="card">
              <h3 className="text-xl font-semibold mb-4">Get In Touch</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-mail mr-3 text-primary">
                    <rect width="20" height="16" x="2" y="4" rx="2"></rect>
                    <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path>
                  </svg>
                  <a href={`mailto:${personalInfo.contact.email}`} className="hover:text-primary transition-colors">
                    {personalInfo.contact.email}
                  </a>
                </div>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-linkedin mr-3 text-primary">
                    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                    <rect width="4" height="12" x="2" y="9"></rect>
                    <circle cx="4" cy="4" r="2"></circle>
                  </svg>
                  <a href={`https://${personalInfo.contact.linkedin}`} target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">
                    LinkedIn Profile
                  </a>
                </div>
              </div>
            </div>
            
            {/* Contact Form */}
            <div className="card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-semibold">Send a Message</h3>
                <label className="flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showMessageField}
                    onChange={() => setShowMessageField(!showMessageField)}
                    className="sr-only peer"
                  />
                  <div className="relative w-11 h-6 bg-muted rounded-full peer peer-checked:bg-primary peer-focus:ring-2 peer-focus:ring-primary transition-colors">
                    <div className="absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform peer-checked:translate-x-5"></div>
                  </div>
                  <span className="ml-2 text-sm text-muted-foreground">
                    {showMessageField ? 'Enabled' : 'Disabled'}
                  </span>
                </label>
              </div>
              
              {showMessageField ? (
                <form onSubmit={handleSubmit}>
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium mb-1">
                        Name
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                        className="contact-input"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium mb-1">
                        Email
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        className="contact-input"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="subject" className="block text-sm font-medium mb-1">
                        Subject
                      </label>
                      <input
                        type="text"
                        id="subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleInputChange}
                        required
                        className="contact-input"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium mb-1">
                        Message
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        required
                        rows="4"
                        className="contact-input"
                      ></textarea>
                    </div>
                    
                    <button type="submit" className="btn btn-primary w-full">
                      Send Message
                    </button>
                    
                    {formStatus.submitted && (
                      <div className={`mt-4 p-3 rounded-md ${formStatus.success ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                        {formStatus.message}
                      </div>
                    )}
                  </div>
                </form>
              ) : (
                <div className="p-4 bg-muted rounded-md text-center">
                  <p>Contact form is currently disabled.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}

export default App;

